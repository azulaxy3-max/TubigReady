TubigReady static policy website
================================

Files:
- index.html: responsive single-page website containing project overview, intended app functions, privacy policy, SMS consent/notification policy, terms/disclaimers, and data-deletion instructions.

BEFORE PUBLISHING:
1. Confirm that azula.xy3@gmail.com is monitored by the project team.
2. Confirm the final app's actual data collection, hosting provider, SMS provider, retention periods, consent/opt-out process, and deletion process. The research paper describes planned functions; it does not establish that all features are already operational.
3. Remove or revise any statements that do not match the actual implementation.
4. Publish index.html using a public HTTPS static host. The resulting URL can be used as the Privacy Policy URL in Meta's app settings only after it is publicly accessible and finalized.
5. Test the page on mobile and open it in a logged-out/private browser window to confirm public access.

This is a static draft and does not itself provide a backend, collect data, send SMS, or process deletion requests.
